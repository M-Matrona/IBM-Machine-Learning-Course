

```python
import os
import cv2
import numpy as np
from PIL import Image
from collections import Counter
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay, accuracy_score
import keras

#from tensorflow.keras.preprocessing.image import ImageDataGenerator
#from tensorflow.keras.models import Sequential
#from tensorflow.keras.layers import Dense, Dropout, Activation, Flatten
#from tensorflow.keras.layers import Conv2D, MaxPooling2D

from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv2D, MaxPooling2D
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.optimizers import Adam,SGD,Adagrad,Adadelta,RMSprop
```

    Using TensorFlow backend.
    


```python
def mse(a,b):
    """function to compute the mean square error between two numpy arrays"""
    return np.square(a-b).mean()

def load_images(data_path):
    """Function to load images from NEU Dataset"""

    images=[] 
    labels=[] 

    for dirpath, dirnames, filenames in os.walk(data_path):
        for filename in filenames:
            defect=dirpath.split('\\')[-1] 
            if '.bmp' in filename:
                images.append(cv2.imread(os.path.join(dirpath,filename),0))
                labels.append(defect)

    images=np.asarray(images)
    labels=np.asarray(labels)

    return images, labels
```


```python
data_path = r'C:\Users\mmatr\Desktop\Learning Data Science\IBM Machine Learning\Git\IBM-Machine-Learning-Course\Course_5_Deep_Learning\NEU Metal Surface Defects Data'
os.chdir(data_path)

data, labels = load_images(data_path)
```


```python
#this is necessary to get the data into the form that to_categorical requires, namely an array of numeric labels
le = LabelEncoder()

labels_ohe = keras.utils.to_categorical(le.fit_transform(labels).reshape(-1,1), 6)
```

## Normalize Data


```python
data=data/255
```


```python
X_train, X_test, y_train, y_test = train_test_split(data, labels_ohe, test_size=0.15)
```


```python
X_train = X_train.reshape(len(X_train),200,200,1)
X_test = X_test.reshape(len(X_test),200,200,1)
```

# First Model

This model will be a contain a single convolution layer. And serve as the skeleton for subsequent models


```python
model = Sequential()
model.add(Conv2D(32, (2,2), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(4, 4))
model.add(Flatten())
model.add(Dense(256))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_1"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_1 (Conv2D)            (None, 199, 199, 32)      160       
    _________________________________________________________________
    max_pooling2d_1 (MaxPooling2 (None, 49, 49, 32)        0         
    _________________________________________________________________
    flatten_1 (Flatten)          (None, 76832)             0         
    _________________________________________________________________
    dense_1 (Dense)              (None, 256)               19669248  
    _________________________________________________________________
    dropout_1 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_2 (Dense)              (None, 6)                 1542      
    =================================================================
    Total params: 19,670,950
    Trainable params: 19,670,950
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model1 = model.fit(X_train,y_train,
        batch_size = 32,
        epochs=10,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/10
    1530/1530 [==============================] - 14s 9ms/step - loss: 39.4688 - accuracy: 0.2235 - val_loss: 9.0801 - val_accuracy: 0.4111
    Epoch 2/10
    1530/1530 [==============================] - 19s 12ms/step - loss: 5.6626 - accuracy: 0.4294 - val_loss: 4.3330 - val_accuracy: 0.4333
    Epoch 3/10
    1530/1530 [==============================] - 18s 12ms/step - loss: 1.4158 - accuracy: 0.6739 - val_loss: 0.9326 - val_accuracy: 0.7481
    Epoch 4/10
    1530/1530 [==============================] - 18s 12ms/step - loss: 0.7560 - accuracy: 0.7993 - val_loss: 0.8466 - val_accuracy: 0.7778
    Epoch 5/10
    1530/1530 [==============================] - 18s 12ms/step - loss: 0.6212 - accuracy: 0.8248 - val_loss: 0.5789 - val_accuracy: 0.7704
    Epoch 6/10
    1530/1530 [==============================] - 19s 12ms/step - loss: 0.5261 - accuracy: 0.8542 - val_loss: 0.6328 - val_accuracy: 0.7815
    Epoch 7/10
    1530/1530 [==============================] - 19s 12ms/step - loss: 0.4142 - accuracy: 0.8810 - val_loss: 0.3781 - val_accuracy: 0.8815
    Epoch 8/10
    1530/1530 [==============================] - 18s 12ms/step - loss: 0.4672 - accuracy: 0.8732 - val_loss: 0.5875 - val_accuracy: 0.8111
    Epoch 9/10
    1530/1530 [==============================] - 18s 12ms/step - loss: 0.3528 - accuracy: 0.9072 - val_loss: 0.3751 - val_accuracy: 0.9000
    Epoch 10/10
    1530/1530 [==============================] - 18s 12ms/step - loss: 0.3650 - accuracy: 0.9000 - val_loss: 0.3462 - val_accuracy: 0.8963
    


```python
plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model1.history['accuracy'])  
plt.plot(history_model1.history['val_accuracy'])  
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_11_0.png)


# Adam Optimizer 

Else the same as above


```python
model = Sequential()
model.add(Conv2D(32, (2,2), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(4, 4))
model.add(Flatten())
model.add(Dense(256))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='Adam',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_2"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_2 (Conv2D)            (None, 199, 199, 32)      160       
    _________________________________________________________________
    max_pooling2d_2 (MaxPooling2 (None, 49, 49, 32)        0         
    _________________________________________________________________
    flatten_2 (Flatten)          (None, 76832)             0         
    _________________________________________________________________
    dense_3 (Dense)              (None, 256)               19669248  
    _________________________________________________________________
    dropout_2 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_4 (Dense)              (None, 6)                 1542      
    =================================================================
    Total params: 19,670,950
    Trainable params: 19,670,950
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model1a = model.fit(X_train,y_train,
        batch_size = 32,
        epochs=10,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/10
    1530/1530 [==============================] - 19s 12ms/step - loss: 7.1737 - accuracy: 0.3791 - val_loss: 1.1524 - val_accuracy: 0.5185
    Epoch 2/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.5917 - accuracy: 0.7693 - val_loss: 0.5574 - val_accuracy: 0.7741
    Epoch 3/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.4228 - accuracy: 0.8464 - val_loss: 0.4814 - val_accuracy: 0.8481
    Epoch 4/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.3597 - accuracy: 0.8758 - val_loss: 0.5366 - val_accuracy: 0.8556
    Epoch 5/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.2856 - accuracy: 0.9092 - val_loss: 0.4619 - val_accuracy: 0.8630
    Epoch 6/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.2940 - accuracy: 0.8980 - val_loss: 0.4232 - val_accuracy: 0.8667
    Epoch 7/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.2746 - accuracy: 0.9046 - val_loss: 0.3968 - val_accuracy: 0.8889
    Epoch 8/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.2137 - accuracy: 0.9353 - val_loss: 0.4240 - val_accuracy: 0.8815
    Epoch 9/10
    1530/1530 [==============================] - 20s 13ms/step - loss: 0.2746 - accuracy: 0.9131 - val_loss: 0.5017 - val_accuracy: 0.8148
    Epoch 10/10
    1530/1530 [==============================] - 19s 13ms/step - loss: 0.2379 - accuracy: 0.9157 - val_loss: 0.3696 - val_accuracy: 0.8741
    


```python
plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model1.history['accuracy'])  
plt.plot(history_model1.history['val_accuracy'])  
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_15_0.png)


# Model 2 

Attempt to reduce overfitting of model 1 - Smaller Dense layer


```python
model = Sequential()
model.add(Conv2D(32, (2,2), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(4, 4))
model.add(Flatten())
model.add(Dense(128))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_3"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_3 (Conv2D)            (None, 199, 199, 32)      160       
    _________________________________________________________________
    max_pooling2d_3 (MaxPooling2 (None, 49, 49, 32)        0         
    _________________________________________________________________
    flatten_3 (Flatten)          (None, 76832)             0         
    _________________________________________________________________
    dense_5 (Dense)              (None, 128)               9834624   
    _________________________________________________________________
    dropout_3 (Dropout)          (None, 128)               0         
    _________________________________________________________________
    dense_6 (Dense)              (None, 6)                 774       
    =================================================================
    Total params: 9,835,558
    Trainable params: 9,835,558
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model2 = model.fit(X_train,y_train,
        batch_size = 32,
        epochs=10,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 16.8942 - accuracy: 0.2706 - val_loss: 1.7403 - val_accuracy: 0.5185
    Epoch 2/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 2.3919 - accuracy: 0.5137 - val_loss: 1.5898 - val_accuracy: 0.5519
    Epoch 3/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.9447 - accuracy: 0.7229 - val_loss: 0.8106 - val_accuracy: 0.7037
    Epoch 4/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.5662 - accuracy: 0.8085 - val_loss: 0.4611 - val_accuracy: 0.8444
    Epoch 5/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.4586 - accuracy: 0.8490 - val_loss: 0.4291 - val_accuracy: 0.8741
    Epoch 6/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.3995 - accuracy: 0.8712 - val_loss: 0.4512 - val_accuracy: 0.8259
    Epoch 7/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.3669 - accuracy: 0.8752 - val_loss: 0.4939 - val_accuracy: 0.8444
    Epoch 8/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.3354 - accuracy: 0.9020 - val_loss: 0.5959 - val_accuracy: 0.7778
    Epoch 9/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.3059 - accuracy: 0.9137 - val_loss: 0.5320 - val_accuracy: 0.8519
    Epoch 10/10
    1530/1530 [==============================] - 15s 10ms/step - loss: 0.2898 - accuracy: 0.9144 - val_loss: 0.5880 - val_accuracy: 0.7778
    


```python

plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model2.history['accuracy'])  
plt.plot(history_model2.history['val_accuracy'])  
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_19_0.png)


# Filter size test


```python
model = Sequential()
model.add(Conv2D(32, (3,3), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(4, 4))
model.add(Flatten())
model.add(Dense(128))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_4"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_4 (Conv2D)            (None, 198, 198, 32)      320       
    _________________________________________________________________
    max_pooling2d_4 (MaxPooling2 (None, 49, 49, 32)        0         
    _________________________________________________________________
    flatten_4 (Flatten)          (None, 76832)             0         
    _________________________________________________________________
    dense_7 (Dense)              (None, 128)               9834624   
    _________________________________________________________________
    dropout_4 (Dropout)          (None, 128)               0         
    _________________________________________________________________
    dense_8 (Dense)              (None, 6)                 774       
    =================================================================
    Total params: 9,835,718
    Trainable params: 9,835,718
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model3 = model.fit(X_train,y_train,
        epochs=10,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/10
    1530/1530 [==============================] - 17s 11ms/step - loss: 16.5457 - accuracy: 0.2765 - val_loss: 0.9956 - val_accuracy: 0.6148
    Epoch 2/10
    1530/1530 [==============================] - 16s 11ms/step - loss: 1.2645 - accuracy: 0.5837 - val_loss: 1.3006 - val_accuracy: 0.5444
    Epoch 3/10
    1530/1530 [==============================] - 16s 11ms/step - loss: 0.9412 - accuracy: 0.7065 - val_loss: 1.4148 - val_accuracy: 0.6000
    Epoch 4/10
    1530/1530 [==============================] - 17s 11ms/step - loss: 0.7124 - accuracy: 0.7771 - val_loss: 0.6471 - val_accuracy: 0.7778
    Epoch 5/10
    1530/1530 [==============================] - 16s 11ms/step - loss: 0.5517 - accuracy: 0.7967 - val_loss: 0.6812 - val_accuracy: 0.7519
    Epoch 6/10
    1530/1530 [==============================] - 16s 11ms/step - loss: 0.5590 - accuracy: 0.8366 - val_loss: 0.4804 - val_accuracy: 0.8333
    Epoch 7/10
    1530/1530 [==============================] - 16s 11ms/step - loss: 0.6423 - accuracy: 0.8281 - val_loss: 0.6932 - val_accuracy: 0.7778
    Epoch 8/10
    1530/1530 [==============================] - 17s 11ms/step - loss: 0.4194 - accuracy: 0.8810 - val_loss: 0.4084 - val_accuracy: 0.8667
    Epoch 9/10
    1530/1530 [==============================] - 16s 11ms/step - loss: 0.5005 - accuracy: 0.8791 - val_loss: 0.4745 - val_accuracy: 0.8259
    Epoch 10/10
    1530/1530 [==============================] - 16s 11ms/step - loss: 0.4813 - accuracy: 0.8817 - val_loss: 0.5635 - val_accuracy: 0.7630
    


```python
plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model3.history['accuracy'])  
plt.plot(history_model3.history['val_accuracy'])  
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_23_0.png)


# Model with a second convolution layer


```python
model = Sequential()
model.add(Conv2D(32, (5,5), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(2, 2))
model.add(Conv2D(32, (3,3), activation='relu'))
model.add(MaxPooling2D(2, 2))
model.add(Flatten())
model.add(Dense(256))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='Adam',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_9"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_15 (Conv2D)           (None, 196, 196, 32)      832       
    _________________________________________________________________
    max_pooling2d_15 (MaxPooling (None, 98, 98, 32)        0         
    _________________________________________________________________
    conv2d_16 (Conv2D)           (None, 96, 96, 32)        9248      
    _________________________________________________________________
    max_pooling2d_16 (MaxPooling (None, 48, 48, 32)        0         
    _________________________________________________________________
    flatten_9 (Flatten)          (None, 73728)             0         
    _________________________________________________________________
    dense_17 (Dense)             (None, 256)               18874624  
    _________________________________________________________________
    dropout_9 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_18 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 18,886,246
    Trainable params: 18,886,246
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model4 = model.fit(X_train,y_train,
        batch_size = 32,
        epochs=10,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 4.0021 - accuracy: 0.2575 - val_loss: 1.4260 - val_accuracy: 0.3259
    Epoch 2/10
    1530/1530 [==============================] - 41s 27ms/step - loss: 1.4389 - accuracy: 0.4150 - val_loss: 1.4433 - val_accuracy: 0.4037
    Epoch 3/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 1.2618 - accuracy: 0.5059 - val_loss: 1.2504 - val_accuracy: 0.5481
    Epoch 4/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 1.0150 - accuracy: 0.6392 - val_loss: 1.0954 - val_accuracy: 0.6074
    Epoch 5/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 0.8474 - accuracy: 0.6954 - val_loss: 0.9826 - val_accuracy: 0.6370
    Epoch 6/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 0.6618 - accuracy: 0.7680 - val_loss: 0.8011 - val_accuracy: 0.7296
    Epoch 7/10
    1530/1530 [==============================] - 41s 27ms/step - loss: 0.4729 - accuracy: 0.8399 - val_loss: 0.7328 - val_accuracy: 0.7852
    Epoch 8/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 0.5150 - accuracy: 0.8242 - val_loss: 0.7245 - val_accuracy: 0.8037
    Epoch 9/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 0.3792 - accuracy: 0.8732 - val_loss: 0.7468 - val_accuracy: 0.8185
    Epoch 10/10
    1530/1530 [==============================] - 40s 26ms/step - loss: 0.2353 - accuracy: 0.9261 - val_loss: 0.6455 - val_accuracy: 0.8111
    


```python
plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model4.history['accuracy'])  
plt.plot(history_model4.history['val_accuracy'])  
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_27_0.png)


## Increasing the number of filters on the second convolution layer


```python
model = Sequential()
model.add(Conv2D(32, (5,5), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(2, 2))
model.add(Conv2D(64, (3,3), activation='relu'))
model.add(MaxPooling2D(2, 2))
model.add(Flatten())
model.add(Dense(256))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='Adam',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_6"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_7 (Conv2D)            (None, 196, 196, 32)      832       
    _________________________________________________________________
    max_pooling2d_7 (MaxPooling2 (None, 98, 98, 32)        0         
    _________________________________________________________________
    conv2d_8 (Conv2D)            (None, 96, 96, 64)        18496     
    _________________________________________________________________
    max_pooling2d_8 (MaxPooling2 (None, 48, 48, 64)        0         
    _________________________________________________________________
    flatten_6 (Flatten)          (None, 147456)            0         
    _________________________________________________________________
    dense_11 (Dense)             (None, 256)               37748992  
    _________________________________________________________________
    dropout_6 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_12 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 37,769,862
    Trainable params: 37,769,862
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model4_2 = model.fit(X_train,y_train,
        batch_size = 32,
        epochs=20,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/20
    1530/1530 [==============================] - 58s 38ms/step - loss: 5.1928 - accuracy: 0.3484 - val_loss: 0.9037 - val_accuracy: 0.6704
    Epoch 2/20
    1530/1530 [==============================] - 57s 37ms/step - loss: 0.7734 - accuracy: 0.7216 - val_loss: 0.6160 - val_accuracy: 0.7889
    Epoch 3/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.6320 - accuracy: 0.7601 - val_loss: 0.6214 - val_accuracy: 0.8074
    Epoch 4/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.3739 - accuracy: 0.8771 - val_loss: 0.4331 - val_accuracy: 0.8481
    Epoch 5/20
    1530/1530 [==============================] - 55s 36ms/step - loss: 0.2774 - accuracy: 0.9111 - val_loss: 0.4204 - val_accuracy: 0.8481
    Epoch 6/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.2379 - accuracy: 0.9170 - val_loss: 0.4826 - val_accuracy: 0.8222
    Epoch 7/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.3185 - accuracy: 0.8915 - val_loss: 0.5027 - val_accuracy: 0.8519
    Epoch 8/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.2038 - accuracy: 0.9373 - val_loss: 0.3757 - val_accuracy: 0.8741
    Epoch 9/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.2728 - accuracy: 0.9052 - val_loss: 0.7378 - val_accuracy: 0.8037
    Epoch 10/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.1554 - accuracy: 0.9569 - val_loss: 0.7016 - val_accuracy: 0.8333
    Epoch 11/20
    1530/1530 [==============================] - 64s 42ms/step - loss: 0.1157 - accuracy: 0.9627 - val_loss: 0.6712 - val_accuracy: 0.8333
    Epoch 12/20
    1530/1530 [==============================] - 63s 41ms/step - loss: 0.0911 - accuracy: 0.9680 - val_loss: 0.8899 - val_accuracy: 0.8074
    Epoch 13/20
    1530/1530 [==============================] - 63s 41ms/step - loss: 0.0798 - accuracy: 0.9784 - val_loss: 0.6074 - val_accuracy: 0.8185
    Epoch 14/20
    1530/1530 [==============================] - 62s 40ms/step - loss: 0.1506 - accuracy: 0.9503 - val_loss: 0.4032 - val_accuracy: 0.8815
    Epoch 15/20
    1530/1530 [==============================] - 53s 35ms/step - loss: 0.0828 - accuracy: 0.9758 - val_loss: 0.4820 - val_accuracy: 0.8704
    Epoch 16/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.0629 - accuracy: 0.9830 - val_loss: 0.5946 - val_accuracy: 0.8741
    Epoch 17/20
    1530/1530 [==============================] - 53s 35ms/step - loss: 0.1027 - accuracy: 0.9686 - val_loss: 0.4932 - val_accuracy: 0.8741
    Epoch 18/20
    1530/1530 [==============================] - 53s 35ms/step - loss: 0.0638 - accuracy: 0.9824 - val_loss: 0.3610 - val_accuracy: 0.9185
    Epoch 19/20
    1530/1530 [==============================] - 54s 36ms/step - loss: 0.0882 - accuracy: 0.9739 - val_loss: 0.6665 - val_accuracy: 0.8519
    Epoch 20/20
    1530/1530 [==============================] - 54s 35ms/step - loss: 0.1020 - accuracy: 0.9634 - val_loss: 0.6104 - val_accuracy: 0.8370
    


```python
plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model4_2.history['accuracy'])  
plt.plot(history_model4_2.history['val_accuracy'])  
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_31_0.png)


# 3 Convolution Layers
Third layer the same depth as the second.


```python
model = Sequential()
model.add(Conv2D(32, (5,5), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(2, 2))
model.add(Conv2D(64, (3,3), activation='relu'))
model.add(MaxPooling2D(2, 2))
model.add(Conv2D(64, (3,3), activation='relu'))
model.add(MaxPooling2D(2, 2))
model.add(Flatten())
model.add(Dense(256))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='Adam',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_7"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_9 (Conv2D)            (None, 196, 196, 32)      832       
    _________________________________________________________________
    max_pooling2d_9 (MaxPooling2 (None, 98, 98, 32)        0         
    _________________________________________________________________
    conv2d_10 (Conv2D)           (None, 96, 96, 64)        18496     
    _________________________________________________________________
    max_pooling2d_10 (MaxPooling (None, 48, 48, 64)        0         
    _________________________________________________________________
    conv2d_11 (Conv2D)           (None, 46, 46, 64)        36928     
    _________________________________________________________________
    max_pooling2d_11 (MaxPooling (None, 23, 23, 64)        0         
    _________________________________________________________________
    flatten_7 (Flatten)          (None, 33856)             0         
    _________________________________________________________________
    dense_13 (Dense)             (None, 256)               8667392   
    _________________________________________________________________
    dropout_7 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_14 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 8,725,190
    Trainable params: 8,725,190
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model5b = model.fit(X_train,y_train,
        batch_size = 32,
        epochs=10,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/10
    1530/1530 [==============================] - 51s 33ms/step - loss: 1.7443 - accuracy: 0.3516 - val_loss: 1.0213 - val_accuracy: 0.5370
    Epoch 2/10
    1530/1530 [==============================] - 51s 34ms/step - loss: 0.7970 - accuracy: 0.7085 - val_loss: 0.7981 - val_accuracy: 0.7148
    Epoch 3/10
    1530/1530 [==============================] - 51s 33ms/step - loss: 0.5707 - accuracy: 0.8131 - val_loss: 0.4806 - val_accuracy: 0.8519
    Epoch 4/10
    1530/1530 [==============================] - 51s 33ms/step - loss: 0.3497 - accuracy: 0.8824 - val_loss: 0.3908 - val_accuracy: 0.8963
    Epoch 5/10
    1530/1530 [==============================] - 51s 33ms/step - loss: 0.3064 - accuracy: 0.8980 - val_loss: 0.3151 - val_accuracy: 0.8963
    Epoch 6/10
    1530/1530 [==============================] - 51s 33ms/step - loss: 0.2397 - accuracy: 0.9203 - val_loss: 0.2942 - val_accuracy: 0.8852
    Epoch 7/10
    1530/1530 [==============================] - 51s 33ms/step - loss: 0.4335 - accuracy: 0.8621 - val_loss: 0.4851 - val_accuracy: 0.8556
    Epoch 8/10
    1530/1530 [==============================] - 50s 33ms/step - loss: 0.5063 - accuracy: 0.8379 - val_loss: 0.5801 - val_accuracy: 0.8185
    Epoch 9/10
    1530/1530 [==============================] - 50s 33ms/step - loss: 0.3005 - accuracy: 0.8993 - val_loss: 0.5222 - val_accuracy: 0.8556
    Epoch 10/10
    1530/1530 [==============================] - 50s 33ms/step - loss: 0.2514 - accuracy: 0.9092 - val_loss: 0.3017 - val_accuracy: 0.9037
    

# 3 Convolution Layers

geometrically increasing depths


```python
plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model5b.history['accuracy'])  
plt.plot(history_model5b.history['val_accuracy'])  
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_36_0.png)



```python
model = Sequential()
model.add(Conv2D(32, (5,5), activation='relu', input_shape=X_train.shape[1:]))
model.add(MaxPooling2D(2, 2))
model.add(Conv2D(64, (3,3), activation='relu'))
model.add(MaxPooling2D(2, 2))
model.add(Conv2D(128, (3,3), activation='relu'))
model.add(MaxPooling2D(2, 2))
model.add(Flatten())
model.add(Dense(256))
model.add(Dropout(0.2))
model.add(Dense(6, activation='softmax'))

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='Adam',
              metrics=['accuracy'])
print('Compiled!')
```

    Model: "sequential_8"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv2d_12 (Conv2D)           (None, 196, 196, 32)      832       
    _________________________________________________________________
    max_pooling2d_12 (MaxPooling (None, 98, 98, 32)        0         
    _________________________________________________________________
    conv2d_13 (Conv2D)           (None, 96, 96, 64)        18496     
    _________________________________________________________________
    max_pooling2d_13 (MaxPooling (None, 48, 48, 64)        0         
    _________________________________________________________________
    conv2d_14 (Conv2D)           (None, 46, 46, 128)       73856     
    _________________________________________________________________
    max_pooling2d_14 (MaxPooling (None, 23, 23, 128)       0         
    _________________________________________________________________
    flatten_8 (Flatten)          (None, 67712)             0         
    _________________________________________________________________
    dense_15 (Dense)             (None, 256)               17334528  
    _________________________________________________________________
    dropout_8 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_16 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 17,429,254
    Trainable params: 17,429,254
    Non-trainable params: 0
    _________________________________________________________________
    Compiled!
    


```python
history_model5 = model.fit(X_train,y_train,
        batch_size = 32,
        epochs=20,
        validation_data=(X_test,y_test),
        verbose=1, shuffle=True)
```

    Train on 1530 samples, validate on 270 samples
    Epoch 1/20
    1530/1530 [==============================] - 59s 39ms/step - loss: 1.5814 - accuracy: 0.4418 - val_loss: 0.9128 - val_accuracy: 0.7444
    Epoch 2/20
    1530/1530 [==============================] - 59s 39ms/step - loss: 0.5511 - accuracy: 0.8065 - val_loss: 0.8072 - val_accuracy: 0.6778
    Epoch 3/20
    1530/1530 [==============================] - 59s 39ms/step - loss: 0.3884 - accuracy: 0.8614 - val_loss: 0.4828 - val_accuracy: 0.8037
    Epoch 4/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.4924 - accuracy: 0.8314 - val_loss: 0.4744 - val_accuracy: 0.8593
    Epoch 5/20
    1530/1530 [==============================] - 59s 39ms/step - loss: 0.2346 - accuracy: 0.9235 - val_loss: 0.2594 - val_accuracy: 0.9074
    Epoch 6/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.2444 - accuracy: 0.9183 - val_loss: 0.3286 - val_accuracy: 0.9000
    Epoch 7/20
    1530/1530 [==============================] - 60s 39ms/step - loss: 0.2794 - accuracy: 0.9111 - val_loss: 0.4427 - val_accuracy: 0.8185
    Epoch 8/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.1992 - accuracy: 0.9379 - val_loss: 0.2261 - val_accuracy: 0.9074
    Epoch 9/20
    1530/1530 [==============================] - 59s 39ms/step - loss: 0.1593 - accuracy: 0.9451 - val_loss: 0.5714 - val_accuracy: 0.9037
    Epoch 10/20
    1530/1530 [==============================] - 58s 38ms/step - loss: 0.2900 - accuracy: 0.9072 - val_loss: 0.3399 - val_accuracy: 0.8815
    Epoch 11/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.2920 - accuracy: 0.9078 - val_loss: 0.3151 - val_accuracy: 0.9111
    Epoch 12/20
    1530/1530 [==============================] - 58s 38ms/step - loss: 0.4138 - accuracy: 0.8699 - val_loss: 0.8021 - val_accuracy: 0.7481
    Epoch 13/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.1941 - accuracy: 0.9399 - val_loss: 0.3866 - val_accuracy: 0.8926
    Epoch 14/20
    1530/1530 [==============================] - 58s 38ms/step - loss: 0.1549 - accuracy: 0.9477 - val_loss: 0.3385 - val_accuracy: 0.9037
    Epoch 15/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.1239 - accuracy: 0.9549 - val_loss: 0.3601 - val_accuracy: 0.8926
    Epoch 16/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.0995 - accuracy: 0.9686 - val_loss: 0.1973 - val_accuracy: 0.9444
    Epoch 17/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.0886 - accuracy: 0.9725 - val_loss: 0.1824 - val_accuracy: 0.9407
    Epoch 18/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.0897 - accuracy: 0.9739 - val_loss: 0.3029 - val_accuracy: 0.9148
    Epoch 19/20
    1530/1530 [==============================] - 58s 38ms/step - loss: 0.1281 - accuracy: 0.9614 - val_loss: 0.2072 - val_accuracy: 0.9222
    Epoch 20/20
    1530/1530 [==============================] - 59s 38ms/step - loss: 0.0677 - accuracy: 0.9797 - val_loss: 0.2921 - val_accuracy: 0.9185
    


```python
plt.figure(1)  
# summarize history for accuracy  
plt.subplot(211)  
plt.plot(history_model5.history['accuracy'])  
plt.plot(history_model5.history['val_accuracy'])
plt.title('model accuracy')  
plt.ylabel('accuracy')  
plt.xlabel('epoch')  
plt.legend(['train', 'test'], loc='upper left')  
plt.show()
```


![png](output_39_0.png)

